package com.saptarshidas.project;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Patterns;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.shashank.sony.fancytoastlib.FancyToast;

public class Register extends Activity {
    Database mydb;
    EditText et_name,et_uname,et_pass,et_cpass;
    TextView title;
    Button btn;
     String name,uname,password,c_password;
     //Database mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_register);
        title=(TextView)findViewById(R.id.clicktologin);
        SpannableString text = new SpannableString("Already Registered? Click to login");
        text.setSpan(new ForegroundColorSpan(0xFF2196F3), 20, 34, 0);
        title.setText(text, TextView.BufferType.SPANNABLE);
        mydb=new Database(this);

        et_name=(EditText)findViewById(R.id.name);
        et_uname=(EditText)findViewById(R.id.username);
        et_pass=(EditText)findViewById(R.id.pass);
       et_cpass=(EditText)findViewById(R.id.confirm_pass);




        btn=(Button)findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name=et_name.getText().toString();
                uname=et_uname.getText().toString().toLowerCase();
                password=et_pass.getText().toString();
                c_password=et_cpass.getText().toString();
                if (name.isEmpty() || name.length()>30)
                    et_name.setError("Please enter a valid name");

               else if (uname.isEmpty() || uname.length()>10)
                    et_uname.setError("Please enter a valid username which should not exceed 10 chars");

                else if (password.isEmpty() || password.length()<8)
                    et_pass.setError("Paaword must be of 8 characters");

                else if (c_password.isEmpty() || !c_password.equals(password))
                    et_cpass.setError("Password did not match");


                else
                    after_pressing_signup();

            }

        });
    }
    public void after_pressing_signup()
    {

        boolean result= mydb.insertUser(name,uname,password);
            if (result==true) {
                Intent goto_login = new Intent(Register.this, Login.class);
                startActivity(goto_login);
                FancyToast.makeText(this,"Successfully Registered",FancyToast.LENGTH_SHORT,FancyToast.SUCCESS,false).show();

                finish();
            }
            else {
                et_uname.setError("Username already exists");
                FancyToast.makeText(this,"Registration failed",FancyToast.LENGTH_SHORT,FancyToast.ERROR,false).show();
            }

    }
    public  void backto_login(View view)
    {
        Intent goto_login = new Intent(Register.this, Login.class);
        startActivity(goto_login);
        finish();
    }



}
