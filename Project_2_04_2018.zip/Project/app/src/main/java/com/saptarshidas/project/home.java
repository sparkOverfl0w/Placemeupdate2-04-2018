package com.saptarshidas.project;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class home extends Activity {
    TextView t,t1,t2;
    Session session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        session=new Session(home.this);
        Database mydb=new Database(this);
        t=(TextView)findViewById(R.id.tv1);
        t1=(TextView)findViewById(R.id.tv2);
        t2=(TextView)findViewById(R.id.textView7);
        Typeface custom_font = Typeface.createFromAsset(getAssets(),  "fonts/prestij.otf");
        t2.setTypeface(custom_font);
        Intent i=getIntent();
        //getting name and username from SelectStream Activty
        final String username=i.getStringExtra("username");
        String name=mydb.getname(username);
        String stream=mydb.getStream(username);  // calling the method to fetch the stream
        t.setText(name);
        t1.setText(" ("+stream+")");
        if (session.loggedIn()){
            String Name=session.getName();
            String Stream=session.getStream();
            t.setText(Name);
            t1.setText(" ("+Stream+")");
        }
    }
    public void job_profile(View view) {
        //will go to job_profile intent
        Toast.makeText(home.this,"Job profile selected",Toast.LENGTH_SHORT).show();

    }
    public void preparation(View view) {
        //will go to job_profile intent
        Toast.makeText(home.this,"Preparation selected",Toast.LENGTH_SHORT).show();

    }
    public void cv(View view) {
        //will go to job_profile intent
        Toast.makeText(home.this,"CV selected",Toast.LENGTH_SHORT).show();

    }
    public void interview(View view) {
        //will go to job_profile intent
        Toast.makeText(home.this,"Interview selected",Toast.LENGTH_SHORT).show();

    }
    public void suggestions(View view) {
        //will go to job_profile intent
        Toast.makeText(home.this,"Suggestions selected",Toast.LENGTH_SHORT).show();

    }
    public void qna(View view) {
        //will go to job_profile intent
        Intent intent=new Intent(home.this,QuestionPapers.class);
        startActivity(intent);



    }
    public void logout(View view){
        AlertDialog.Builder a_dialog=new AlertDialog.Builder(home.this);
        a_dialog.setMessage("Do you really want to logout?");
        a_dialog.setCancelable(false);
        a_dialog.setPositiveButton(Html.fromHtml("<font color='#2C3E50'>Yes</font>"), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                session.setLoggedin(false);
                Intent intent=new Intent(home.this,Login.class);
                startActivity(intent);
                finish();
            }
        }).setNegativeButton(Html.fromHtml("<font color='#2C3E50'>no</font>"), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog alert=a_dialog.create();
        alert.setTitle("Logout!");
        alert.show();


    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder a_dialog=new AlertDialog.Builder(home.this);
        a_dialog.setMessage("Do you really want to exit?");
        a_dialog.setCancelable(false);
        a_dialog.setPositiveButton(Html.fromHtml("<font color='#2C3E50'>Yes</font>"), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        }).setNegativeButton(Html.fromHtml("<font color='#2C3E50'>no</font>"), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog alert=a_dialog.create();
        alert.show();


    }
}

