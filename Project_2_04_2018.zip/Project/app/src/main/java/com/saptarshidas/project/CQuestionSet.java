package com.saptarshidas.project;


public class CQuestionSet {
    public String questions[]={
            "Who is father of C Language?",
            "C Language developed at _________?",
            "For 16-bit compiler allowable range for integer constants is ________?",
            "C programs are converted into machine language with the help of",
            " Which of the following about the following two declaration is  true\n" +
                    " i ) int *F()\n" +
                    " ii) int (*F)()",//5
            "What are the values printed by the following program? \n" +
                    " #define dprint(expr) printf(#expr \"=%d \",expr) \n" +
                    " main()\n" +
                    " {\n" +
                    " int x=7;\n" +
                    " int y=3;\n" +
                    " dprintf(x/y);\n" +
                    " }", //6
            "output of the following. \n" +
                    " main()\n" +
                    " {\n" +
                    " int i;\n" +
                    " char *p;\n" +
                    " i=0X89;\n" +
                    " p=(char *)i;\n" +
                    " p++;\n" +
                    " printf(\"%x \",p);\n" +
                    " } ",
            "Which of the following is not a ANSI C language keyword?",
            "When an array is passed as parameter to a function, which of  the following statement is correct",
            "The type of the controlling expression of a switch statement cannot be of the type",
            "What is the value of the expression (3^6) + (a^a)?",
            "What is the value assigned to the variable X if b is 7 ?\n" +
                    " X = b>8 ? b <<3 : b>4 ? b>>1:b;",
            "Which is the output produced by the following program\n" +
                    " main()\n" +
                    " {\n" +
                    " int n=2;\n" +
                    " printf(\"%d %d \", ++n, n*n);\n" +
                    " }",
            "What is th output of the following program?\n" +
                    " int x= 0x65;\n" +
                    " main()\n" +
                    " {\n" +
                    " char x;\n" +
                    " printf(\"%d \",x)\n" +
                    " }",
            "What is the output of the following program\n" +
                    " main()\n" +
                    " {\n" +
                    " int a=10;\n" +
                    " int b=6;\n" +
                    " \n" +
                    " if(a=3)\n" +
                    " b++;\n" +
                    " printf(\"%d %d \",a,b++);\n" +
                    " }",
            "What can be said of the following program?\n" +
                    " main()\n" +
                    " {\n" +
                    " enum Months {JAN =1,FEB,MAR,APR};\n" +
                    " Months X = JAN;\n" +
                    " if(X==1)\n" +
                    " {\n" +
                    " printf(\"Jan is the first month\");\n" +
                    " }\n" +
                    " }",
            "What is the output of the following problem ?\n" +
                    " #define INC(X) X++\n" +
                    " main()\n" +
                    " {\n" +
                    " int X=4;\n" +
                    " printf(\"%d\",INC(X++));\n" +
                    " }",
            "Which of the following typecasting is accepted by C",
            "Which type conversion is NOT accepted?",
            "What is the output of this C code?\n" +
                    "\n" +
                    "    #include <stdio.h>\n" +
                    "    int main()\n" +
                    "    {\n" +
                    "        int a = 0, i = 0, b;\n" +
                    "        for (i = 0;i < 5; i++)\n" +
                    "        {\n" +
                    "            a++;\n" +
                    "            if (i == 3)\n" +
                    "                break;\n" +
                    "        }\n" +
                    "    }"
    };

    public String choices[][]={
            {"Bjarne Stroustrup","James A. Gosling","Dennis Ritchie","Dr. E.F. Codd"},
            {"AT & T's Bell Laboratories of USA in 1972","AT & T's Bell Laboratories of USA in 1970","Sun Microsystems in 1973","Cambridge University in 1972"},
            {"-3.4e38 to 3.4e38","-32767 to 32768","-32668 to 32667","-32768 to 32767"},
            {"An Editor","A compiler","An operating system","None of the above"},
            {"Both are identical","The first is a correct declaration and the second is wrong","The first declaraion is a function returning a pointer to an integer and the second is a pointer to function returning int","Both are different ways of declarin pointer to a function"},
            {"#2 = 2","expr=2","x/y=2","none"},
            {"0X8A","0X8C","0X8D","0X8AE"},
            {"Function","volatile","signed","register"},
            {"The function can change values in the original array","In C parameters are passed by value. The funciton cannot  change the original value in the array","It results in compilation error when the function tries to  access the elements in the array","Results in a run time error when the funtion tries to access  the elements in"},
            {"int","char","short","float"},
            {"3","5","6","a+18"},
            {"7","28","3","14"},
            {"3,6","3,4","2,4","cannot determine"},
            {"compilation error","'A'","65","unidentified"},
            {"10,6","10,7","3,6","3,7"},
            {"Does not print anything","Prints : Jan is the first month","Generates compilation error","Results in runtime error"},
            {"4","5","6","compilation error"},
            {"Widening conversions","Narrowing conversions","Widening & Narrowing conversions","None of the mentioned"},
            {"From char to int","From float to char pointer","From negative int to char","From double to char"},
            {"1","2","3","4"}
    };

    public String answers[]={
            "Dennis Ritchie",
            "AT & T's Bell Laboratories of USA in 1972",
            "-32768 to 32767",
            "A compiler",
            "The first declaraion is a function returning a pointer to an integer and the second is a pointer to function returning int",
            "x/y=2",
            "0X8A",
            "Function",
            "The function can change values in the original array",
            "float",
            "5",
            "3",
            "3,4",
            "compilation error",
            "3,7",
            "Prints : Jan is the first month",
            "compilation error",
            "Widening & Narrowing conversions",
            "From float to char pointer",
            "4"
    };

    public String getQuestion(int n){
        String question=questions[n];
        return question;
    }

    public String getChoice1(int n){
        String choice1=choices[n][0];
        return choice1;
    }
    public String getChoice2(int n){
        String choice2=choices[n][1];
        return choice2;
    }
    public String getChoice3(int n){
        String choice3=choices[n][2];
        return choice3;
    }
    public String getChoice4(int n){
        String choice4=choices[n][3];
        return choice4;
    }
    public String getAnswer(int n){
        String correctAnswer=answers[n];
        return correctAnswer;
    }
    public int QArrayLength(){
        int Qlength=questions.length;
        return Qlength;
    }
}
