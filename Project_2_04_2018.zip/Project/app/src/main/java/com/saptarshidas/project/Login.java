package com.saptarshidas.project;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.shashank.sony.fancytoastlib.FancyToast;

public class Login extends Activity {
    EditText et_user,et_pass;
    TextView reg,title;
    String user,pass;
    Session session;

Database mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_login);
        title=(TextView)findViewById(R.id.loginTitle);
        Typeface custom_font = Typeface.createFromAsset(getAssets(),  "fonts/prestij.otf");
        title.setTypeface(custom_font);
        session=new Session(Login.this);
        mydb=new Database(this);
        et_user=(EditText)findViewById(R.id.username);
        et_pass=(EditText)findViewById(R.id.password);
        reg=(TextView)findViewById(R.id.register);
        SpannableString text = new SpannableString("Not Registered? Register here");
        text.setSpan(new ForegroundColorSpan(0xFF2196F3), 16, 29, 0);
        reg.setText(text, TextView.BufferType.SPANNABLE);
    }

        public void login(View view) {
        user=et_user.getText().toString();
        pass=et_pass.getText().toString();
        String fetched_pass=mydb.getpass(user);
        String feteched_name=mydb.getname(user);
        String fetched_stream=mydb.getStream(user);
        if (pass.equals(fetched_pass)) {

            FancyToast.makeText(this,"Login Successful",FancyToast.LENGTH_SHORT,FancyToast.SUCCESS,false).show();
            if (fetched_stream==null) {

                Intent choose_stream = new Intent(Login.this, SelectStream.class);
                choose_stream.putExtra("username", user);
                choose_stream.putExtra("Name", feteched_name);
                startActivity(choose_stream);
                finish();

            }
            else {
                session.setLoggedin(true);
                session.setName(feteched_name);
                session.setStream(fetched_stream);
                Intent go_home = new Intent(Login.this, home.class);
               go_home.putExtra("username", user);
                startActivity(go_home);
                finish();
            }
        }
         else {

            FancyToast.makeText(this,"Login failed",FancyToast.LENGTH_SHORT,FancyToast.ERROR,false).show();
        }
        }

        public void register_user(View view)
        {
            Intent reg_user=new Intent(Login.this,Register.class);
            startActivity(reg_user);
            FancyToast.makeText(this,"Register here",FancyToast.LENGTH_SHORT,FancyToast.DEFAULT,false).show();
            finish();
        }


}

