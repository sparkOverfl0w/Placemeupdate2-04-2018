package com.saptarshidas.project;

/**
 * Created by sapta on 1/27/2018.
 */

public class CPlusPlusQuestionSet {
    public String questions[]={
            "Which of the following access specifies is used in a class definition by default?\n" +
                    "\n",
            "Which of the following means \"The use of an object of one class in definition of another class\"?\n" +
                    "\n",
            "Which of the following also known as an instance of a class?\n" +
                    "\n",
            "Which of the following type of class allows only one object of it to be created?\n" +
                    "\n",
            "Which of the following is not a type of constructor?\n" +
                    "\n",
            "Which of the following statements is correct?",
            "Which of the following is not the member of class?",
            "Which of the following concepts means determining at runtime what method to invoke?",
            "Which of the following is a mechanism of static polymorphism?",
            "Which of the following is correct about the statements given below?\n" +
                    "\n" +
                    "All operators can be overloaded in C++.\n" +
                    "We can change the basic meaning of an operator in C++",
            "What happens if the base and derived class contains definition of a function with same prototype?",
            "What is the output of the following program?\n" +
                    "\n" +
                    "#include<iostream>\n" +
                    "\n" +
                    "using namespace std;\n" +
                    "main() { \n" +
                    "   float t = 2;\n" +
                    "\t\n" +
                    "\tswitch(t) {\n" +
                    "      case 2: cout<<”Hi”;\n" +
                    "\t\tdefault: cout<<\"Hello\";\n" +
                    "\t}\n" +
                    "}",
            "C++ Inheritance relationship is",
            "False statements about function overloading is",
            "Which of the following cannot be overloaded in C++",
            "Constant function in C++ can be declared as",
            "What is the output of the program\n" +
                    "\n" +
                    "#include<iostream.h>\n" +
                    "void main()\n" +
                    "{\n" +
                    "int n=1;\n" +
                    "cout<<endl<<“The numbers are;”<<endl;\n" +
                    "do\n" +
                    "{\n" +
                    "cout <<n<<“t”;\n" +
                    "n++;\n" +
                    "} while (n<=100);\n" +
                    "cout <<endl;\n" +
                    "}",
            "What is the output of this program?\n" +
                    "\n" +
                    "    #include <iostream>\n" +
                    "    using namespace std;\n" +
                    "    void print(int i)\n" +
                    "    {\n" +
                    "        cout << i;\n" +
                    "    }\n" +
                    "    void print(double  f)\n" +
                    "    {\n" +
                    "        cout << f;\n" +
                    "    }\n" +
                    "    int main(void)\n" +
                    "    {\n" +
                    "        print(5);\n" +
                    "        print(500.263);\n" +
                    "        return 0;\n" +
                    "    }",
            "What is the output of this program?\n" +
                    "\n" +
                    "    #include <iostream>\n" +
                    "    using namespace std;\n" +
                    "    void func(int a, bool flag = true)\n" +
                    "    {\n" +
                    "        if (flag == true ) \n" +
                    "        {\n" +
                    "            cout << \"Flag is true. a = \" << a;\n" +
                    "        }\n" +
                    "        else \n" +
                    "        {\n" +
                    "            cout << \"Flag is false. a = \" << a;\n" +
                    "        }\n" +
                    "    }\n" +
                    "    int main()\n" +
                    "    {\n" +
                    "        func(200, false);\n" +
                    "        return 0;\n" +
                    "    }",
            "What is the output of this program?\n" +
                    "\n" +
                    "    #include <iostream>\n" +
                    "    #include <string>\n" +
                    "    using namespace std;\n" +
                    "    string askNumber(string prompt = \"Please enter a number: \");\n" +
                    "    int main()\n" +
                    "    {\n" +
                    "        string number = askNumber();\n" +
                    "        cout << \"Here is your number: \" << number;\n" +
                    "        return 0;\n" +
                    "    }\n" +
                    "    string askNumber(string prompt)\n" +
                    "    {\n" +
                    "        string number;\n" +
                    "        cout << prompt;\n" +
                    "        cin >> number;\n" +
                    "        return number;\n" +
                    "    }"

    };

    public String choices[][]={
            {"Protected","Public","Private","Friend"},
            {"Encapsulation","Inheritance","Composition","Abstraction"},
            {"Friend Functions","Object","Member Functions","Member Variables"},
            {"Virtual class","Abstract class","Singleton class","Friend class"},
            {"Copy constructor","Friend constructor","Default constructor","Parameterized constructor"},
            {"Base class pointer cannot point to derived class","Derived class pointer cannot point to base class","Pointer to derived class cannot be created","Pointer to base class cannot be created"},
            {"Static function","Friend function","Const function","Virtual function"},
            {"Data hiding","Dynamic Typing","Dynamic binding","Dynamic loading"},
           {"Operator overloading","Function overloading","Templates","All of the above"},
            {"Only I is true","Both I and II are false","Only II is true","Both I and II are true"},
            {"Compiler reports an error on compilation","Only base class function will get called irrespective of object","Only derived class function will get called irrespective of object","Base class object will call base class function and derived class object will call derived class function"},
            {"Hi","HiHello","Hello","Error"},
            {"Association","Is-A","Has-A","None"},
            {"Defining multiple functions with same name in a class is called function overloading","Overloaded function must differ in their order and types of arguments","Overloaded functions should be preceded with virtual keyword","No statement is false"},
            {"Increment operator","Constructor","Destructor","New and delete operator"},
            {"void display()","void display() const","const void display()","void const display()"},
            {"Print natural numbers 0 to 99","Print natural numbers 1 to 99","Print natural numbers 0 to 100","Print natural numbers 1 to 100"},
            {"5500.263","500.2635","500.263","none of the mentioned"},
            {"Flag is true. a = 200","Flag is false. a = 100","Flag is false. a = 200","Flag is true. a = 100"},
            {"5","6","the number you entered","compile time error"}

    };

    public String answers[]={
            "Private",
            "Composition",
            "Object",
            "Singleton class",
            "Friend constructor",
            "Derived class pointer cannot point to base class",
            "Friend function",
            "Dynamic binding",
            "All of the above",
            "Both I and II are false",
            "Base class object will call base class function and derived class object will call derived class function",
            "Error",
            "Is-A",
            "Overloaded functions should be preceded with virtual keyword",
            "New and delete operator",
            "void display() const",
            "Print natural numbers 0 to 100","Print natural numbers 1 to 100",
            "5500.263",
            "Flag is false. a = 200",
            "the number you entered"

    };

    public String getQuestion(int n){
        String question=questions[n];
        return question;
    }

    public String getChoice1(int n){
        String choice1=choices[n][0];
        return choice1;
    }
    public String getChoice2(int n){
        String choice2=choices[n][1];
        return choice2;
    }
    public String getChoice3(int n){
        String choice3=choices[n][2];
        return choice3;
    }
    public String getChoice4(int n){
        String choice4=choices[n][3];
        return choice4;
    }
    public String getAnswer(int n){
        String correctAnswer=answers[n];
        return correctAnswer;
    }
    public int QArrayLength(){
        int Qlength=questions.length;
        return Qlength;
    }
}
