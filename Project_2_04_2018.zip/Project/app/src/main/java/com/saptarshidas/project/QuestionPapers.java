package com.saptarshidas.project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.shashank.sony.fancytoastlib.FancyToast;

public class QuestionPapers extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question_papers);
    }
    public void hcl_papers(View view){
        FancyToast.makeText(this,"HCL papers selected !", FancyToast.LENGTH_SHORT,FancyToast.INFO,false).show();
        Intent intent=new Intent(QuestionPapers.this,HCL.class);
        startActivity(intent);
    }
   /* @Override
    public void onBackPressed()
    {
        super.onBackPressed();
        startActivity(new Intent(QuestionPapers.this, home.class));
        finish();

    }   */
}
