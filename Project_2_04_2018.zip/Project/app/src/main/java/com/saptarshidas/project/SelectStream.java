package com.saptarshidas.project;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.shashank.sony.fancytoastlib.FancyToast;

public class SelectStream extends Activity {
    RadioGroup rg;
    Button b;
     RadioButton rb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_stream);
        final Database mydb=new Database(this);
        rg=(RadioGroup)findViewById(R.id.rg);
        b=(Button)findViewById(R.id.button);
        Intent i=getIntent();   //getting the Name of user from Login Activity
        final String name=i.getStringExtra("Name");

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = getIntent(); // for getting the USERNAME of user from Login Activty
                String usern = i.getStringExtra("username");
                int b_id = rg.getCheckedRadioButtonId();
                if (b_id == -1) {
                    FancyToast.makeText(SelectStream.this, "Please select a stream", FancyToast.LENGTH_SHORT, FancyToast.DEFAULT, false).show();
                } else {
                    rb = (RadioButton) findViewById(b_id);
                    String stream = rb.getText().toString();


                    boolean result = mydb.updateUserStream(usern, stream); //calling the method to update the stream of user
                    if (result == true) {


                        Intent intent = new Intent(SelectStream.this, Login.class);
                        // intent.putExtra("name", name); //sending the Users's Name to home Activity
                        //intent.putExtra("username", usern);//sending the Users' Username to home Activty
                        startActivity(intent);
                        FancyToast.makeText(SelectStream.this, "Login again to continue", FancyToast.LENGTH_SHORT, FancyToast.INFO, false).show();

                        finish();
                    } else {
                        FancyToast.makeText(SelectStream.this, "Try againz", FancyToast.LENGTH_SHORT, FancyToast.ERROR, false).show();

                    }
                }
            }
        });




    }

}
