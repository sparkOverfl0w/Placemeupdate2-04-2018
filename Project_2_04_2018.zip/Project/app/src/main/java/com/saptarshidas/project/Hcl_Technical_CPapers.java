package com.saptarshidas.project;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.nfc.Tag;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.shashank.sony.fancytoastlib.FancyToast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import static android.content.ContentValues.TAG;

public class Hcl_Technical_CPapers extends Activity {
    TextView questionS,questionNo,ans1,ans2,ans3,ans4;
    String correctAns;
    String papername;
    int qNo=0;
    int score=0;
     MediaPlayer correctsound;
     MediaPlayer wrongsound;
     CardView c1,c2,c3,c4;
    CQuestionSet cquestion;
    CPlusPlusQuestionSet cplusquestion;
    ArrayList<Item> questionList;
     int questionLength;
     int currentquestion=0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hcl__technical__cpapers);
        //representing the cardviews
        c1=(CardView)findViewById(R.id.cardchoice1);
        c2=(CardView)findViewById(R.id.cardchoice2);
        c3=(CardView)findViewById(R.id.cardchoice3);
        c4=(CardView)findViewById(R.id.cardchoice4);
        //representing the sounds
        correctsound=MediaPlayer.create(Hcl_Technical_CPapers.this,R.raw.correctans);
        wrongsound=MediaPlayer.create(Hcl_Technical_CPapers.this,R.raw.wrongans);
       // representing the question ,choices, and answer views
        questionS=(TextView)findViewById(R.id.Questionset);
        questionNo=(TextView)findViewById(R.id.QuestionNumber);
        ans1=(TextView)findViewById(R.id.answer1);
        ans2=(TextView)findViewById(R.id.answer2);
        ans3=(TextView)findViewById(R.id.answer3);
        ans4=(TextView)findViewById(R.id.answer4);
        //catching the papername
        Intent intent=getIntent();
        papername=intent.getStringExtra("PaperName");
        if (papername.equals("C Papers")) {
            cquestion = new CQuestionSet();
            questionList = new ArrayList<>();
            questionLength = cquestion.QArrayLength();
            //saving all questions , choices and answers in a list
            for (int i = 0; i < questionLength; i++) {
                questionList.add(new Item(cquestion.getQuestion(i), cquestion.getChoice1(i), cquestion.getChoice2(i), cquestion.getChoice3(i), cquestion.getChoice4(i), cquestion.getAnswer(i)));
            }
            //shuffling the list
            Collections.shuffle(questionList);
        /*Starting the quiz by passing currentquestion=0 and invoking the updateQuestion() method by default,
         after that the updateQuestion() method will be invoked and currentquestion will be
          increased by 1 only after each cardView click*/
            updateQuestion(currentquestion);


        }
        else if (papername.equals("C++ Papers")){
            cplusquestion=new CPlusPlusQuestionSet();
            questionList = new ArrayList<>();
            questionLength = cplusquestion.QArrayLength();

            for (int i = 0; i < questionLength; i++) {
                questionList.add(new Item(cplusquestion.getQuestion(i), cplusquestion.getChoice1(i), cplusquestion.getChoice2(i), cplusquestion.getChoice3(i), cplusquestion.getChoice4(i), cplusquestion.getAnswer(i)));
            }

            Collections.shuffle(questionList);
            updateQuestion(currentquestion);

        }
        else {
            Toast.makeText(getApplicationContext(),"This is not C",Toast.LENGTH_SHORT).show();
        }

    }
    /*This method will set the questions choices and correctanswer to the views when invoked*/
    public void updateQuestion(int index){
        questionS.setText(questionList.get(index).getQuestions());
        ans1.setText(questionList.get(index).getChoice1());
        ans2.setText(questionList.get(index).getChoice2());
        ans3.setText(questionList.get(index).getChoice3());
        ans4.setText(questionList.get(index).getChoice4());
        correctAns=(questionList.get(index).getAnswer());
         qNo++;
         String q=String.valueOf(qNo);
        if (papername.equals("C Papers")) {
            questionNo.setText("C Language Test - Q" + q + "/Q20");//q=1
        }
        if (papername.equals("C++ Papers")){
            questionNo.setText("C++ Language Test - Q" + q + "/Q20");
        }

    }

    //Checking choice 1
    public void choice1(View view){
        if(ans1.getText().toString().equals(correctAns)){
            score=score+1;
            correctsound.start();
            c1.setCardBackgroundColor(Color.parseColor("#27AE60"));//green
            FancyToast.makeText(this,"Correct",FancyToast.LENGTH_SHORT, FancyToast.SUCCESS,false).show();

            delayQuestionupdate();
        }
        else{
            wrongsound.start();
            c1.setCardBackgroundColor(Color.parseColor("#E74C3C")); //red
            if (ans2.getText().toString().equals(correctAns)){
                c2.setCardBackgroundColor(Color.parseColor("#27AE60"));
            }
            if (ans3.getText().toString().equals(correctAns)){
                c3.setCardBackgroundColor(Color.parseColor("#27AE60"));
            }
            if (ans4.getText().toString().equals(correctAns)){
                c4.setCardBackgroundColor(Color.parseColor("#27AE60"));
            }
            FancyToast.makeText(this,"Wrong",FancyToast.LENGTH_SHORT, FancyToast.ERROR,false).show();
            delayQuestionupdate();
        }
    }
    //checking choice 2
    public void choice2(View view){
        if(ans2.getText().toString().equals(correctAns)){
            score=score+1;
            correctsound.start();
            c2.setCardBackgroundColor(Color.parseColor("#27AE60"));
            FancyToast.makeText(this,"Correct",FancyToast.LENGTH_SHORT, FancyToast.SUCCESS,false).show();
            delayQuestionupdate();

        }
        else{
            wrongsound.start();
            c2.setCardBackgroundColor(Color.parseColor("#E74C3C"));
            if (ans1.getText().toString().equals(correctAns)){
                c1.setCardBackgroundColor(Color.parseColor("#27AE60"));
            }
            if (ans3.getText().toString().equals(correctAns)){
                c3.setCardBackgroundColor(Color.parseColor("#27AE60"));
            }
            if (ans4.getText().toString().equals(correctAns)){
                c4.setCardBackgroundColor(Color.parseColor("#27AE60"));
            }
            FancyToast.makeText(this,"Wrong",FancyToast.LENGTH_SHORT, FancyToast.ERROR,false).show();
            delayQuestionupdate();

        }
    }
   //checking choice 3
    public void choice3(View view){
        if(ans3.getText().toString().equals(correctAns)){
            score=score+1;
            correctsound.start();
            c3.setCardBackgroundColor(Color.parseColor("#27AE60"));
            FancyToast.makeText(this,"Correct",FancyToast.LENGTH_SHORT, FancyToast.SUCCESS,false).show();
            delayQuestionupdate();

        }
        else{
            c3.setCardBackgroundColor(Color.parseColor("#E74C3C"));
            wrongsound.start();
            if (ans1.getText().toString().equals(correctAns)){
                c1.setCardBackgroundColor(Color.parseColor("#27AE60"));
            }
            if (ans2.getText().toString().equals(correctAns)){
                c2.setCardBackgroundColor(Color.parseColor("#27AE60"));
            }
            if (ans4.getText().toString().equals(correctAns)){
                c4.setCardBackgroundColor(Color.parseColor("#27AE60"));
            }
            FancyToast.makeText(this,"Wrong",FancyToast.LENGTH_SHORT, FancyToast.ERROR,false).show();
            delayQuestionupdate();
        }
    }
     //checking choice 4
    public void choice4(View view){
        if(ans4.getText().toString().equals(correctAns)){
            score=score+1;
            correctsound.start();
            c4.setCardBackgroundColor(Color.parseColor("#27AE60"));
            FancyToast.makeText(this,"Correct",FancyToast.LENGTH_SHORT, FancyToast.SUCCESS,false).show();
            delayQuestionupdate();

        }
        else{
            c4.setCardBackgroundColor(Color.parseColor("#E74C3C"));
            wrongsound.start();
            if (ans1.getText().toString().equals(correctAns)){
                c1.setCardBackgroundColor(Color.parseColor("#27AE60"));
            }
            if (ans2.getText().toString().equals(correctAns)){
                c2.setCardBackgroundColor(Color.parseColor("#27AE60"));
            }
            if (ans3.getText().toString().equals(correctAns)){
                c3.setCardBackgroundColor(Color.parseColor("#27AE60"));
            }
            FancyToast.makeText(this,"Wrong",FancyToast.LENGTH_SHORT, FancyToast.ERROR,false).show();
          delayQuestionupdate();
        }
    }
    /* This method will check the questionNo. if it is getting equal to the questionArrayLength
     * if found equal then it will start the statictics activty and will show the score else it will
      *  keep updating the questions*/
    public void checkQuestionLength(){
     if(qNo>=questionLength){
         finish();
         Intent intent=new Intent(Hcl_Technical_CPapers.this,TrackTest.class);
         String s=String.valueOf(score);
         String paper_name[]={"C Language","C plusplus"};
         intent.putExtra("score", s);
         if (papername.equals("C Papers")) {
             intent.putExtra("papername", paper_name[0]);
         }
         if (papername.equals("C++ Papers")) {
             intent.putExtra("papername", paper_name[1]);
         }
         startActivity(intent);
     }
     else {
         currentquestion++;

         updateQuestion(currentquestion);
         resetCardCColor();

     }
    }
    /*This method will delay the questionupdate by 2 second*/
    public void delayQuestionupdate(){
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                //2 sec gap

                checkQuestionLength();
            }
        }, 2000);

    }
    /*This method will reset the cardview colors to white after each questionupdate*/
    public void resetCardCColor(){
        c1.setCardBackgroundColor(Color.parseColor("#FDFEFE"));
        c2.setCardBackgroundColor(Color.parseColor("#FDFEFE"));
        c3.setCardBackgroundColor(Color.parseColor("#FDFEFE"));
        c4.setCardBackgroundColor(Color.parseColor("#FDFEFE"));

    }






}
