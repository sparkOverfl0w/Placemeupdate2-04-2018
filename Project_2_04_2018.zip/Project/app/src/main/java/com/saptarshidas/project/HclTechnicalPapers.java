package com.saptarshidas.project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class HclTechnicalPapers extends AppCompatActivity {
    TextView t1;
    String paperName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hcl_technical_papers);
        t1=(TextView)findViewById(R.id.cpaper);
    }
    public void cPapers(View view){

        paperName="C Papers";
        Intent intent=new Intent(HclTechnicalPapers.this,Hcl_Technical_CPapers.class);
        intent.putExtra("PaperName",paperName);
        startActivity(intent);
    }
    public void cplusPapers(View view){

        paperName="C++ Papers";
        Intent intent=new Intent(HclTechnicalPapers.this,Hcl_Technical_CPapers.class);
        intent.putExtra("PaperName",paperName);
        startActivity(intent);

    }

}
