package com.saptarshidas.project;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class HCL extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hcl);
    }
    public void TechQuestions(View view){
        Intent intent=new Intent(HCL.this,HclTechnicalPapers.class);
        startActivity(intent);
    }

}
