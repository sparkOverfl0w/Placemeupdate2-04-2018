package com.saptarshidas.project;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

public class TrackTest extends Activity {
    TextView title,score,paper_name,questions;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_track_test);
        Typeface custom_font = Typeface.createFromAsset(getAssets(),  "fonts/kenteken.ttf");
        title=(TextView)findViewById(R.id.tv1);
        title.setTypeface(custom_font);
        questions=(TextView)findViewById(R.id.tv2);
        questions.setTypeface(custom_font);
        paper_name=(TextView)findViewById(R.id.tv3);
        paper_name.setTypeface(custom_font);
        score=(TextView)findViewById(R.id.tv4);
        score.setTypeface(custom_font);
        Intent intent=getIntent();
        String s=intent.getStringExtra("score");
        String p=intent.getStringExtra("papername");
        score.setText("Your Score-"+s);
        paper_name.setText("Paper-"+p);
    }
    public void goBack(View view){
        finish();
    }

}
