package com.saptarshidas.project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by sapta on 11/2/2017.
 */

public class Database extends SQLiteOpenHelper {
    public static final String DATABASE="Registrations";
    public static final String TABLE="Users";
    public static final String column_1="NAME";
    public static final String column_2="USERNAME";
    public static final String column_3="PASSWORD";
    public static final String column_4="STREAM";

    public Database(Context context) {
        super(context, DATABASE, null, 1);
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table "+TABLE+"(NAME TEXT,USERNAME TEXT PRIMARY KEY,PASSWORD TEXT,STREAM TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+TABLE);
        onCreate(sqLiteDatabase);
    }
    public boolean insertUser(String name, String user, String pass){
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(column_1,name);
        values.put(column_2,user);
        values.put(column_3,pass);
        long result= sqLiteDatabase.insert(TABLE,null,values);
        if (result==-1)
            return false;
        else
            return true;


    }
    // For updating the stream of a user
    public boolean updateUserStream(String uname, String stream){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(column_4,stream);
        String[] args = new String[]{uname};
        long result= db.update(TABLE, values, "USERNAME=?",args);
        if (result==1)
            return true;
        else
            return false;
    }
    // For fetching the password
    public String getpass(String uname)
    {
        SQLiteDatabase db=this.getReadableDatabase();
        String query="SELECT USERNAME,PASSWORD FROM "+TABLE;
        Cursor cursor=db.rawQuery(query,null);
        String fetched_uname;
        String pass="not found";
        if (cursor.moveToFirst())
        {
            do{
                fetched_uname=cursor.getString(0);
                if (fetched_uname.equals(uname)){
                    pass=cursor.getString(1);
                    break;

                }
            }
            while (cursor.moveToNext());
        }
        return pass;


    }
    public String getname(String uname){
        SQLiteDatabase db=this.getReadableDatabase();
        String query="SELECT USERNAME,NAME FROM "+TABLE;
        Cursor cursor=db.rawQuery(query,null);
        String fetched_uname;
        String fetched_name="not found";
        if (cursor.moveToFirst())
        {
            do{
                fetched_uname=cursor.getString(0);
                if (fetched_uname.equals(uname)){
                    fetched_name=cursor.getString(1);

                    break;

                }
            }
            while (cursor.moveToNext());
        }
        return fetched_name;

    }
    public String getStream(String uname){
        SQLiteDatabase db=this.getReadableDatabase();
        String query="SELECT USERNAME,STREAM FROM "+TABLE;
        Cursor cursor=db.rawQuery(query,null);
        String fetched_uname;
        String fetched_stream="NOT FOUND";
        if(cursor.moveToFirst()){
            do {
                fetched_uname=cursor.getString(0);
                if(fetched_uname.equals(uname)){
                    fetched_stream=cursor.getString(1);
                    break;
                }

            }
            while (cursor.moveToNext());

        }
        return fetched_stream;
    }



}