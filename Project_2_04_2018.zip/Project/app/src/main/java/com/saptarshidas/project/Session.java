package com.saptarshidas.project;

import android.content.Context;
import android.content.SharedPreferences;


/**
 * Created by sapta on 1/7/2018.
 */

public class Session {
   public SharedPreferences sharedPreferences;
  public SharedPreferences.Editor edit;
     Context context;
    String name;

    public String getStream() {
        stream=sharedPreferences.getString("stream","");
        return stream;
    }

    public void setStream(String stream) {
        this.stream = stream;
        edit.putString("stream",stream);
        edit.commit();
    }

    String stream;

    public String getName() {
        name=sharedPreferences.getString("name","");
        return name;
    }

    public void setName(String name) {
        this.name = name;
        edit.putString("name",name);
        edit.commit();
    }


     public Session(Context ctx){
         context=ctx;
         sharedPreferences=context.getSharedPreferences("usersession",Context.MODE_PRIVATE);
         edit=sharedPreferences.edit();

     }

     public void setLoggedin(Boolean loggedin){
         edit.putBoolean("loggedin",loggedin);
         edit.commit();
     }
     public boolean loggedIn(){
        return sharedPreferences.getBoolean("loggedin",false);

     }

}
