package com.saptarshidas.project;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Typeface;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Window;
import android.widget.TextView;

public class MainActivity extends Activity {
    static int welcome_timer=2000;
    TextView title;

    Session session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         session=new Session(MainActivity.this);
         new Handler().postDelayed(new Runnable() {
             @Override
             public void run() {
                 if(session.loggedIn()){
                     Intent intent=new Intent(MainActivity.this,home.class);
                     startActivity(intent);
                 }
                 else {
                     Intent intent=new Intent(MainActivity.this,Login.class);
                     startActivity(intent);

                 }
             }
         },welcome_timer);


    }
}
