package com.saptarshidas.project;

/**
 * Created by sapta on 1/10/2018.
 */

public class Item {
    String questions,choice1,choice2,choice3,choice4,answer;

    public Item(String questions, String choice1,String choice2,String choice3,String choice4,String answer) {
        this.questions = questions;
        this.choice1=choice1;
        this.choice2=choice2;
        this.choice3=choice3;
        this.choice4=choice4;
        this.answer=answer;


    }

    public String getQuestions() {
        return questions;
    }
    public String getChoice1(){
        return choice1;
    }
    public String getChoice2(){
        return choice2;
    }
    public String getChoice3(){
        return choice3;
    }
    public String getChoice4(){
        return choice4;
    }
    public  String getAnswer(){
        return answer;
    }
}
